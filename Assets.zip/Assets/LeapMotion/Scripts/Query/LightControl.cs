﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class LightControl : MonoBehaviour {

    public static bool m_bLightBtnDisable;
    public Light m_lLight_1;
    public Rect m_rLightWindowRect;
    public Texture m_tCloseButtonTexture;
    public float m_fIntensityMin;//最小值
    public float m_fIntensityMax;//最大值
    //控制第一个灯
    public bool m_bIntensityIsOfMin;//是否最小
    public bool m_bIntensityIsOfMax;//是否最大

    private bool[] isChange = new bool[] { false, false };
    private bool m_bIsClickLightButton;
    public static bool m_bIsShowLightWindowRect;
    // Use this for initialization
	void Start () {

        m_bLightBtnDisable = true;
        m_rLightWindowRect = new Rect(30, 120, 310, 80);
        m_fIntensityMin = 0.0f;
        m_fIntensityMax = 1.0f;
        m_bIntensityIsOfMin = false;
        m_bIntensityIsOfMax = false;
        m_bIsClickLightButton = false;
        m_bIsShowLightWindowRect = false;
	}
	
	// Update is called once per frame
	void Update () {
		
	}
    void OnGUI()
    {
        GUI.backgroundColor = Color.yellow;
        if (GUI.Button(new Rect(20, 10, 100, 50), "灯光设置"))
        {
            if (m_bLightBtnDisable)
            {
                Debug.Log("弹出灯光设置window窗口");
                m_bIsClickLightButton = true;
                m_bIsShowLightWindowRect = true;
            }
        }
        if (m_bIsClickLightButton && m_bIsShowLightWindowRect)
        {
            GUI.color = Color.green;
            m_rLightWindowRect = GUI.Window(0, m_rLightWindowRect, LightWindowEditEvent, "灯光调节面板");
        }

    }
    void LightWindowEditEvent(int windowID)
    {
        if (GUI.Button(new Rect(284, 2, 24, 24), m_tCloseButtonTexture))
        {
            m_bIsShowLightWindowRect = false;
        }
        GUI.Label(new Rect(10, 15, 90, 20), "环境光1");
        m_bIntensityIsOfMin = GUI.Toggle(new Rect(10, 35, 30, 30), m_bIntensityIsOfMin, "弱");
        m_bIntensityIsOfMax = GUI.Toggle(new Rect(240, 35, 30, 30), m_bIntensityIsOfMax, "强");
        m_lLight_1.intensity = GUI.HorizontalSlider(new Rect(40, 40, 200, 30), m_lLight_1.intensity, m_fIntensityMin, m_fIntensityMax);
        GUI.DragWindow(new Rect(0, 0, 10000, 10000));
        if (m_bIntensityIsOfMin && !isChange[0])
        {
            Debug.Log("你选择了弱！");
            m_bIntensityIsOfMax = false;
            m_lLight_1.intensity = m_fIntensityMin;
            isChange = new bool[] { true, false };
        }
        //是否点击 “强”开关
        if (m_bIntensityIsOfMax && !isChange[1])
        {
            m_bIntensityIsOfMin = false;
            m_lLight_1.intensity = m_fIntensityMax;
            isChange = new bool[] { false, true };
        }


    }
}
