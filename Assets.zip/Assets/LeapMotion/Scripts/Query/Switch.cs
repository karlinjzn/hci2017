﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Leap;

public class Switch : MonoBehaviour {
   /* public float fadeSpeed = 2f;
    public bool lightintense;
    public bool lightweak;
    private float targetIntensity;          // 灯强度改变的目标强度值
    public float highIntensity = 2f;        // 灯最大强度值
    public float lowIntensity = 0.5f;       // 灯最小强度值
    public float changeMargin = 0.2f;       // 阈值，决定何时改变强度变化的方向*/

    //Controller controller;
    //if (boollight == true)
    public void LightOn()
    {
        this.GetComponent<Light>().enabled = true;
    }

    public void LightOn2()
    {
        //System.Threading.Thread.Sleep(1000);
        this.GetComponent<Light>().enabled = true;
    }

    //if (boollight == false)
    public void LightOff()
    {
        this.GetComponent<Light>().enabled = false;
    }
    //public GameObject PointLight;
    //public bool boollight;
    public void LightOff2()
    {
        //System.Threading.Thread.Sleep(1000);
        this.GetComponent<Light>().enabled = false;
    }
    public void LightIntense()
    {
        //lightintense = true;
        //this.GetComponent<Light>().intensity = Mathf.Lerp(this.GetComponent<Light>().intensity, 8f, fadeSpeed * Time.deltaTime);

    }

    public void LightWeak()
    {
        //lightweak = true;
        //this.GetComponent<Light>().intensity = Mathf.Lerp(4f, 0f, Time.time);
        //this.GetComponent<Light>().intensity -= 1;
    }


	// Use this for initialization
	void Start () {

	}
	
	// Update is called once per frame
	void Update () {

        }
}
